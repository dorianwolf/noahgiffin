$(function() {

  $('.overline').animate({
    width: $('.audio-engineer').width()-27
	}, 3000);

});
