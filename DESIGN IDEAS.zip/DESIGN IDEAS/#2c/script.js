$(function() {

  $('.overline').animate({
    width: 180
	}, 3000);

});
